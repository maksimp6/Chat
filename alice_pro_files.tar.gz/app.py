"""Alice Pro - Main Application (Final with Dual Metadata Sync)"""
import json
import logging
import os
import asyncio
import uuid
import time
import threading
from flask import Flask, jsonify, render_template, request, Response
from config import Config, get_model_info, calculate_cost, TEXT_MODELS, VOICE_MODELS
from yandex_client import YandexClientError, YandexResponsesClient, YandexRealtimeClient
import db

os.makedirs('logs', exist_ok=True)
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("alice_pro")

app = Flask(__name__)
client = YandexResponsesClient(Config)

voice_sessions = {}
voice_loop = None
voice_thread = None

def get_voice_loop():
    global voice_loop, voice_thread
    if voice_loop is None or voice_loop.is_closed():
        voice_loop = asyncio.new_event_loop()
        voice_thread = threading.Thread(target=voice_loop.run_forever, daemon=True)
        voice_thread.start()
    return voice_loop

def run_async(coro):
    return asyncio.run_coroutine_threadsafe(coro, get_voice_loop()).result(timeout=30)

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/models")
def get_models():
    return jsonify({"text": TEXT_MODELS, "voice": VOICE_MODELS})

# === Управление диалогами ===

@app.get("/api/conversations")
def list_conversations():
    try:
        return jsonify({"conversations": db.get_conversations()})
    except Exception as e:
        logger.error(f"[API] List conversations failed: {e}")
        return jsonify({"conversations": []}), 502

@app.post("/api/conversations")
def create_conv():
    data = request.get_json(silent=True) or {}
    model_key = data.get("model", "aliceai-llm")
    try:
        res = client.create_conversation()
        conv_id = res.get("id")
        title = "Новый диалог"
        
        # Сначала пишем локально
        db.create_conversation(conv_id, title, model_key)
        
        # Затем синхронизируем с Яндексом (некритично)
        try:
            client.update_conversation_metadata(conv_id, {"title": title})
        except Exception as e:
            logger.debug(f"[YANDEX] Initial metadata sync skipped: {e}")
            
        return jsonify({"id": conv_id, "model": model_key})
    except YandexClientError as e:
        return jsonify({"error": str(e)}), 502

@app.delete("/api/conversations/<conv_id>")
def delete_conv(conv_id):
    # Удаляем локально
    db.delete_conversation(conv_id)
    
    # Пробуем удалить в Яндексе (если поддерживается)
    try:
        resp = client.session.delete(client.conversations_url + "/" + conv_id, timeout=5)
        if resp.status_code not in (200, 204, 405):
            logger.warning(f"[YANDEX] Delete returned {resp.status_code} for {conv_id}")
    except Exception as e:
        logger.debug(f"[YANDEX] Delete skipped/failed: {e}")
        
    return jsonify({"status": "ok"})

@app.patch("/api/conversations/<conv_id>")
def rename_conv(conv_id):
    data = request.get_json(silent=True) or {}
    title = data.get("title", "").strip()
    if not title:
        return jsonify({"error": "empty title"}), 400
        
    try:
        # Обновляем локально
        db.update_conversation_title(conv_id, title)
        
        # Синхронизируем с Яндексом
        try:
            client.update_conversation_metadata(conv_id, {"title": title})
        except Exception as e:
            logger.debug(f"[YANDEX] Metadata sync skipped on rename: {e}")
            
        return jsonify({"status": "ok"})
    except Exception as e:
        return jsonify({"error": str(e)}), 502

# === История и Чат ===

@app.get("/api/conversations/<conv_id>/messages")
def get_conv_messages(conv_id):
    try:
        resp = client.session.get(client.conversations_url + "/" + conv_id, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        
        messages = []
        for item in data.get("items", []):
            if item.get("type") == "message":
                role = item.get("role", "")
                text = ""
                for part in item.get("content", []):
                    p_type = part.get("type", "")
                    if p_type in ("text", "output_text", "input_text"):
                        text = part.get("text", "")
                if text.strip():
                    messages.append({"role": role, "text": text, "cost": 0})
                    
        logger.info(f"[API] Loaded {len(messages)} messages from Yandex for {conv_id}")
        return jsonify({"messages": messages})
        
    except Exception as e:
        logger.error(f"[API] Failed to load history for {conv_id}: {e}")
        return jsonify({"messages": [], "error": str(e)}), 502

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "").strip()
    conv_id = data.get("conversation_id")
    model_key = data.get("model", "aliceai-llm")
    
    reply = ""
    usage = None
    cost = 0
    
    if not message:
        return jsonify({"error": "empty"}), 400
        
    try:
        result = client.ask(message, model_key, conv_id)
        reply = client.extract_text(result)
        usage = client.extract_usage(result)
        cost = calculate_cost(model_key, 
                             usage["input_tokens"] if usage else 0, 
                             usage["output_tokens"] if usage else 0)
        
        # Авто-переименование с двойной синхронизацией
        try:
            current_title = db.get_conversation_title(conv_id)
            if current_title == "Новый диалог":
                title = message[:50] + ("..." if len(message) > 50 else "")
                
                # Локально
                db.update_conversation_title(conv_id, title)
                
                # В Яндекс
                try:
                    client.update_conversation_metadata(conv_id, {"title": title})
                except Exception:
                    pass
        except Exception:
            pass
            
        # Запись в холодный архив
        db.add_message(conv_id, "user", message, cost=0, model=model_key, source="rest")
        db.add_message(conv_id, "assistant", reply, cost=cost, usage=usage, model=model_key, source="rest")
        
        return jsonify({"reply": reply, "usage": usage, "cost": cost})
        
    except YandexClientError as e:
        logger.error(f"[CHAT] Yandex error: {e}")
        return jsonify({"error": str(e)}), 502
    except Exception as e:
        logger.error(f"[CHAT] Unexpected error: {e}", exc_info=True)
        return jsonify({"error": "Internal server error"}), 500

# === Voice Endpoints ===

@app.post("/api/voice/session")
def create_voice_session():
    data = request.get_json(silent=True) or {}
    model_key = data.get("model", "speech-realtime-260528")
    voice = data.get("voice", "kirill")
    conv_id = data.get("conversation_id")
    response_mode = data.get("response_mode", "audio")
    
    sid = str(uuid.uuid4())
    rt = YandexRealtimeClient(Config, model_key, voice, conv_id, response_mode=response_mode)
    q = asyncio.Queue()
    
    try:
        ok = run_async(rt.connect())
        if not ok: return jsonify({"error": "Connect failed"}), 502
        
        asyncio.run_coroutine_threadsafe(rt.listen(q), get_voice_loop())
        voice_sessions[sid] = {"client": rt, "queue": q, "conv_id": conv_id, "model": model_key}
        return jsonify({"session_id": sid})
    except Exception as e:
        logger.error("Voice session error: %s", e, exc_info=True)
        return jsonify({"error": str(e)}), 502

@app.post("/api/voice/audio")
def send_voice_audio():
    try:
        sid = request.args.get("session_id")
        if not sid or sid not in voice_sessions: return jsonify({"error": "Invalid session"}), 400
        audio_bytes = request.get_data()
        if not audio_bytes: return jsonify({"error": "No audio"}), 400
        run_async(voice_sessions[sid]["client"].send_audio_binary(audio_bytes))
        return jsonify({"status": "ok"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.get("/api/voice/events")
def voice_events():
    sid = request.args.get("session_id")
    if sid not in voice_sessions: return jsonify({"error": "Invalid"}), 400
    
    q = voice_sessions[sid]["queue"]
    conv_id = voice_sessions[sid].get("conv_id")
    model_key = voice_sessions[sid].get("model", "speech-realtime-260528")
    user_text = ""
    agent_text = ""

    def generate():
        nonlocal user_text, agent_text
        while sid in voice_sessions:
            try:
                evt = run_async(asyncio.wait_for(q.get(), timeout=2.0))
                evt_type = evt.get("type", "")
                
                if evt_type == "conversation.item.input_audio_transcription.completed":
                    user_text = evt.get("transcript", "")
                elif evt_type in ("response.output_text.delta", "response.audio_transcript.delta"):
                    agent_text += evt.get("delta", "")
                elif evt_type == "response.done":
                    usage = evt.get("response", {}).get("usage", {})
                    input_tokens = usage.get("input_tokens", 0)
                    output_tokens = usage.get("output_tokens", 0)
                    total_cost = calculate_cost(model_key, input_tokens, output_tokens)
                    
                    if user_text and agent_text:
                        try:
                            db.add_message(conv_id, "user", user_text, cost=0, model=model_key, source="voice")
                            db.add_message(conv_id, "assistant", agent_text, cost=total_cost, usage=usage, model=model_key, source="voice")
                        except Exception as db_err:
                            logger.error(f"[DB] Voice archive write failed: {db_err}")
                            
                    yield "data: %s\n\n" % json.dumps({"type": "billing_update", "cost": total_cost}, ensure_ascii=False)
                    user_text = ""
                    agent_text = ""
                    
                yield "data: %s\n\n" % json.dumps(evt, ensure_ascii=False)
            except asyncio.TimeoutError: continue
            except Exception as e:
                logger.error("[SSE] Error: %s", e, exc_info=True)
                break
                
    return Response(generate(), mimetype="text/event-stream", headers={"Cache-Control": "no-cache"})

@app.post("/api/voice/close")
def close_voice():
    data = request.get_json(silent=True) or {}
    sid = data.get("session_id")
    if sid in voice_sessions:
        try: run_async(voice_sessions[sid]["client"].close())
        except: pass
        del voice_sessions[sid]
    return jsonify({"status": "ok"})

@app.get("/api/export/dataset")
def export_dataset():
    rows = db.get_all_messages_for_ml()
    lines = []
    for r in rows:
        lines.append(json.dumps({
            "conversation_id": r["conv_id"],
            "role": r["role"],
            "text": r["text"],
            "is_voice": r.get("source") == "voice",
            "cost": r.get("cost", 0),
            "model": r.get("model", ""),
            "timestamp": r.get("timestamp", 0)
        }, ensure_ascii=False))
    
    return Response("\n".join(lines), mimetype="application/jsonl", 
                   headers={"Content-Disposition": "attachment; filename=dataset.jsonl"})

if __name__ == "__main__":
    logger.info("Alice Pro on http://%s:%s", Config.HOST, Config.PORT)
    app.run(host=Config.HOST, port=Config.PORT, threaded=True, debug=False)
