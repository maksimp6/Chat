"""Alice Pro - SQLite Archive (Optimized & Safe)"""
import sqlite3
import json
import time
import os
from contextlib import contextmanager

DB_FILE = "alice_archive.db"

def _init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    # Устанавливаем WAL один раз при инициализации
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL") 
    
    c.execute('''CREATE TABLE IF NOT EXISTS conversations (
        id TEXT PRIMARY KEY, title TEXT, model TEXT, created_at INTEGER
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conv_id TEXT NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL,
        cost REAL DEFAULT 0, model TEXT DEFAULT '', source TEXT DEFAULT 'rest',
        usage TEXT DEFAULT '{}', timestamp INTEGER NOT NULL
    )''')
    c.execute('CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conv_id)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_msg_ts ON messages(timestamp)')
    conn.commit()
    conn.close()

_init_db()

@contextmanager
def get_connection():
    """Получение соединения. WAL уже настроен в _init_db."""
    conn = sqlite3.connect(DB_FILE, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def create_conversation(conv_id, title, model_key):
    try:
        with get_connection() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO conversations VALUES (?, ?, ?, ?)",
                (conv_id, title, model_key, int(time.time()))
            )
            conn.commit()
    except Exception as e:
        __import__('logging').getLogger("alice_pro").error(f"[DB] Create conv failed: {e}")

def add_message(conv_id, role, text, cost=0, usage=None, model="", source="rest"):
    try:
        with get_connection() as conn:
            # ИСПРАВЛЕНО: json.dumps вместо str()
            usage_json = json.dumps(usage or {})
            conn.execute(
                "INSERT INTO messages (conv_id, role, text, cost, model, source, usage, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (conv_id, role, text, cost, model, source, usage_json, int(time.time()))
            )
            conn.commit()
    except Exception as e:
        __import__('logging').getLogger("alice_pro").error(f"[DB] Add message failed: {e}")

def get_all_messages_for_ml():
    with get_connection() as conn:
        cursor = conn.execute(
            "SELECT conv_id, role, text, cost, model, source, usage, timestamp FROM messages ORDER BY timestamp ASC"
        )
        return [dict(row) for row in cursor.fetchall()]

def get_messages(conv_id):
    with get_connection() as conn:
        cursor = conn.execute(
            "SELECT role, text, cost, model, source, usage, timestamp FROM messages WHERE conv_id=? ORDER BY timestamp ASC",
            (conv_id,)
        )
        return [dict(row) for row in cursor.fetchall()]

def delete_conversation(conv_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM messages WHERE conv_id=?", (conv_id,))
        conn.execute("DELETE FROM conversations WHERE id=?", (conv_id,))
        conn.commit()

def get_conversations():
    with get_connection() as conn:
        cursor = conn.execute("SELECT id, title, model, created_at FROM conversations ORDER BY created_at DESC")
        return [dict(row) for row in cursor.fetchall()]
