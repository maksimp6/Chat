"""Alice Pro - Yandex API Client (Full Debug Logging)"""
import json
import time
import requests
import asyncio
import websockets
from websockets.protocol import State
import logging
import os

os.makedirs('logs', exist_ok=True)

api_logger = logging.getLogger("yandex_api_debug")
api_logger.setLevel(logging.DEBUG)
if not api_logger.handlers:
    fh = logging.FileHandler("logs/api_debug.txt", encoding="utf-8", mode='a')
    fh.setFormatter(logging.Formatter('%(asctime)s | %(message)s'))
    api_logger.addHandler(fh)

class YandexClientError(Exception):
    pass

class YandexResponsesClient:
    def __init__(self, config):
        self._config = config
        self.base_url = config.BASE_URL.rstrip("/")
        self.responses_url = self.base_url + "/responses"
        self.conversations_url = self.base_url + "/conversations"
        
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": "Api-Key " + config.API_KEY,
            "Content-Type": "application/json",
            "OpenAI-Project": config.PROJECT_ID,
        })

    def _log_req(self, method, url, **kwargs):
        api_logger.info(f"[REQ] {method} {url}")
        if kwargs.get('json'):
            api_logger.debug(f"[REQ BODY] {json.dumps(kwargs['json'], ensure_ascii=False)[:500]}")

    def _log_resp(self, resp):
        status = resp.status_code
        api_logger.info(f"[RESP] {status} {resp.url}")
        if status >= 400:
            try: api_logger.error(f"[ERR] {resp.text[:500]}")
            except: pass
        else:
            # Баг 2: Логируем тело успешных ответов
            try: api_logger.debug(f"[RESP BODY] {resp.text[:500]}")
            except: pass
        return resp

    def create_conversation(self):
        """Баг 3: Логируем полученный ID диалога"""
        try:
            self._log_req("POST", self.conversations_url, json={})
            resp = self._log_resp(self.session.post(self.conversations_url, json={}, timeout=10))
            resp.raise_for_status()
            data = resp.json()
            api_logger.info(f"[CONV] Created: id={data.get('id')}")
            return data
        except requests.RequestException as e:
            raise YandexClientError("Create conv: " + str(e))

    def update_conversation_metadata(self, conv_id, metadata):
        try:
            url = f"{self.conversations_url}/{conv_id}"
            self._log_req("POST", url, json={"metadata": metadata})
            resp = self._log_resp(
                self.session.post(url, json={"metadata": metadata}, timeout=10)
            )
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            raise YandexClientError("Update metadata: " + str(e))

    def ask(self, message, model_key, conversation_id=None):
        """Баг 5: Логируем task_id при создании задачи"""
        payload = {
            "model": "gpt://" + self._config.PROJECT_ID + "/" + model_key + "/latest",
            "input": [{"role": "user", "content": message}],
            "instructions": "Ты — полезный ассистент.",
            "background": True,
        }
        if conversation_id:
            payload["conversation"] = {"id": conversation_id}
            
        self._log_req("POST", self.responses_url, json=payload)
        try:
            resp = self._log_resp(self.session.post(self.responses_url, json=payload, timeout=60))
            resp.raise_for_status()
            task_id = resp.json().get("id")
            api_logger.info(f"[ASK] Task created: {task_id} (model={model_key}, conv={conversation_id})")
            return self._wait(task_id)
        except requests.RequestException as e:
            raise YandexClientError("Ask: " + str(e))

    def _wait(self, task_id, timeout=120):
        """Баг 4: Логируем статус поллинга и завершение задачи"""
        start = time.time()
        url = self.responses_url + "/" + task_id
        delay = 0.5
        api_logger.info(f"[WAIT] Polling task {task_id}")
        
        while time.time() - start < timeout:
            self._log_req("GET", url)
            resp = self._log_resp(self.session.get(url, timeout=10))
            resp.raise_for_status()
            data = resp.json()
            
            status = data.get("status")
            api_logger.debug(f"[WAIT] Status: {status}")
            
            if status in ("completed", "failed", "cancelled"):
                api_logger.info(f"[WAIT] Done: {status} (task={task_id})")
                if status != "completed":
                    api_logger.error(f"[WAIT] Task failed: {data.get('error', 'unknown')}")
                return data
                
            time.sleep(delay)
            delay = min(delay * 1.5, 3)
            
        api_logger.error(f"[WAIT] Timeout for task {task_id}")
        raise YandexClientError("Timeout waiting for task " + task_id)

    @staticmethod
    def extract_text(data):
        """Баг 6: Предупреждение, если текст не найден"""
        if data.get("output_text"): return data["output_text"]
        for item in data.get("output", []):
            if isinstance(item, dict) and item.get("type") == "message" and item.get("role") == "assistant":
                for part in item.get("content", []):
                    if isinstance(part, dict) and part.get("type") == "output_text" and part.get("text"):
                        return part["text"]
        api_logger.warning(f"[EXTRACT] No text found in response: {json.dumps(data, ensure_ascii=False)[:300]}")
        return data.get("text") or ""

    @staticmethod
    def extract_usage(data):
        u = data.get("usage")
        if not u: return None
        return {
            "input_tokens": u.get("input_tokens", 0),
            "output_tokens": u.get("output_tokens", 0),
            "total_tokens": u.get("total_tokens", 0),
        }


class YandexRealtimeClient:
    def __init__(self, config, model_key, voice="kirill", conversation_id=None, response_mode="audio"):
        self._config = config
        self.base_url = config.BASE_URL.rstrip("/")
        ws_base = self.base_url.replace("https://", "wss://").replace("http://", "ws://")
        self.ws_url = f"{ws_base}/realtime?model=gpt://{config.PROJECT_ID}/{model_key}"
        
        self.api_key = config.API_KEY
        self.model_key = model_key
        self.voice = voice
        self.conversation_id = conversation_id
        self.response_mode = response_mode
        self.ws = None
        self.session_id = None

    async def connect(self):
        headers = {
            "Authorization": "Api-Key " + self.api_key,
            "OpenAI-Project": self._config.PROJECT_ID,
        }
        api_logger.info(f"[WS CONNECT] {self.ws_url}")

        try:
            self.ws = await websockets.connect(
                self.ws_url, additional_headers=headers, ping_interval=20, ping_timeout=10
            )
            api_logger.info("[WS CONNECT] OK")
        except Exception as e:
            api_logger.error(f"[WS CONNECT] Failed: {e}")
            return False

        if self.response_mode == "text": out_mods = ["text"]
        elif self.response_mode == "both": out_mods = ["text", "audio"]
        else: out_mods = ["audio"]

        session_config = {
            "instructions": "Ты — полезный голосовой ассистент. Отвечай кратко и по делу на русском языке.",
            "output_modalities": out_mods,
            "audio": {
                "input": {"format": {"type": "audio/pcm", "rate": 24000}, "turn_detection": {"type": "server_vad", "threshold": 0.5, "silence_duration_ms": 800}},
                "output": {"format": {"type": "audio/pcm", "rate": 24000}, "voice": self.voice}
            }
        }
        if self.conversation_id: session_config["conversation_id"] = self.conversation_id

        payload = {"type": "session.update", "session": session_config}
        api_logger.info(f"[WS SESSION] Sending: {json.dumps(payload, ensure_ascii=False)}")
        await self.ws.send(json.dumps(payload))

        try:
            resp = await asyncio.wait_for(self.ws.recv(), timeout=15)
            data = json.loads(resp)
            api_logger.info(f"[WS SESSION] Response: {data.get('type')}")
            
            if data.get("error"):
                api_logger.error(f"[WS SESSION] Error: {json.dumps(data['error'])}")
                return False
            if data.get("type") in ("session.created", "session.updated"):
                self.session_id = data.get("session", {}).get("id")
                api_logger.info(f"[WS SESSION] ID: {self.session_id}")
                return True
            return False
        except Exception as e:
            api_logger.error(f"[WS SESSION] Failed: {e}")
            return False

    async def send_audio_binary(self, audio_bytes: bytes):
        if self.ws and self.ws.state == State.OPEN:
            try: await self.ws.send(audio_bytes)
            except Exception as e: api_logger.error(f"[WS AUDIO] Send failed: {e}")

    async def listen(self, queue):
        if not self.ws: return
        try:
            async for msg in self.ws:
                if isinstance(msg, bytes): continue
                try:
                    data = json.loads(msg)
                    if data.get("type") == "error":
                        api_logger.error(f"[WS LISTEN] Server error: {json.dumps(data)}")
                    await queue.put(data)
                except json.JSONDecodeError: continue
        except websockets.exceptions.ConnectionClosed as e:
            api_logger.info(f"[WS LISTEN] Closed: {e}")
            await queue.put({"type": "connection_closed", "message": str(e)})
        except Exception as e:
            api_logger.error(f"[WS LISTEN] Error: {e}")
            await queue.put({"type": "error", "message": str(e)})

    async def close(self):
        if self.ws: await self.ws.close()
