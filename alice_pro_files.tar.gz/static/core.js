let currentConvId = null;
let conversations = JSON.parse(localStorage.getItem("conversations") || "[]");
let currentModel = "aliceai-llm";
let currentModelType = "text";
let modelsData = {text: {}, voice: {}};

const urlParams = new URLSearchParams(window.location.search);
const urlConvId = urlParams.get('conversation_id');
if (urlConvId) {
    currentConvId = urlConvId;
    localStorage.setItem("current_conv_id", urlConvId);
} else {
    currentConvId = localStorage.getItem("current_conv_id") || null;
}

const savedTheme = localStorage.getItem("theme") || "light";
document.documentElement.setAttribute("data-theme", savedTheme);

document.addEventListener("DOMContentLoaded", function() {
    var themeToggle = document.getElementById("theme-toggle");
    if (themeToggle) {
        themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
        themeToggle.addEventListener("click", function() {
            var cur = document.documentElement.getAttribute("data-theme");
            var next = cur === "dark" ? "light" : "dark";
            document.documentElement.setAttribute("data-theme", next);
            localStorage.setItem("theme", next);
            themeToggle.textContent = next === "dark" ? "☀️" : "🌙";
        });
    }
    fetch("/api/models").then(function(r) { return r.json(); }).then(function(data) {
        modelsData = data;
        if (typeof updateUIForModel === "function") updateUIForModel();
        if (typeof updateModelButton === "function") updateModelButton();
    });
});

function getMessages(id) { return JSON.parse(localStorage.getItem("messages_" + id) || "[]"); }
function saveMessages(id, msgs) { localStorage.setItem("messages_" + id, JSON.stringify(msgs)); }

window.updateUIForModel = function() {
    var micBtn = document.getElementById("mic-btn");
    var uploadBtn = document.getElementById("upload-image-btn");
    var modeWrap = document.getElementById("response-mode-wrap");
    var isVoice = !!(modelsData.voice && modelsData.voice[currentModel]);
    var isMultimodal = !!(modelsData.text && modelsData.text[currentModel] && modelsData.text[currentModel].multimodal);
    if (micBtn) micBtn.style.display = isVoice ? "flex" : "none";
    if (uploadBtn) uploadBtn.style.display = isMultimodal ? "flex" : "none";
    if (modeWrap) modeWrap.style.display = isVoice ? "flex" : "none";
};
